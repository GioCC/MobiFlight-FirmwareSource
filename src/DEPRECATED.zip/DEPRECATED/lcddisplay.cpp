#include "MFBoards.h"
#include "MFLCDDisplay.h"
#include "commandmessenger.h"
#include "config.h"
#include <Arduino.h>

#define MAX_MFLCD_I2C 2

#if MF_LCD_SUPPORT == 1

MFLCDDisplay lcd_I2C[MAX_MFLCD_I2C];
uint8_t      lcd_12cRegistered = 0;

void         AddLcdDisplay(uint8_t address, uint8_t cols, uint8_t lines, char const *name)
{
    if (lcd_12cRegistered == MAX_MFLCD_I2C)
        return;
    // registerPin(SDA, kTypeLcdDisplayI2C);
    // registerPin(SCL, kTypeLcdDisplayI2C);

    lcd_I2C[lcd_12cRegistered].attach(address, cols, lines);
    lcd_12cRegistered++;
    #ifdef DEBUG
    cmdMessenger.sendCmd(kStatus, F("Added lcdDisplay"));
    #endif
}

void ClearLcdDisplays()
{
    for (int i = 0; i != lcd_12cRegistered; i++) {
        lcd_I2C[lcd_12cRegistered].detach();
    }
    // clearRegisteredPins(kTypeLcdDisplayI2C);
    lcd_12cRegistered = 0;
    #ifdef DEBUG
    cmdMessenger.sendCmd(kStatus, F("Cleared lcdDisplays"));
    #endif
}

void OnSetLcdDisplayI2C()
{
    int   address = cmdMessenger.readInt16Arg();
    char *output  = cmdMessenger.readStringArg();
    lcd_I2C[address].display(output);
    setLastCommandMillis(millis());
}

#endif